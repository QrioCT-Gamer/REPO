# ShrubLibrary merged ESign repo

One merged ESign/AltStore-compatible JSON feed built from the ShrubLibrary source list.

## Files

- `sources.txt` — source repository URLs
- `build.py` — downloads and merges the sources
- `esign.json` — generated feed
- `.github/workflows/update.yml` — automatic rebuild
- `.github/workflows/pages.yml` — GitHub Pages deployment

## Setup

Upload the entire package to `QrioCT-Gamer/REPO`.

Then go to **Settings → Pages** and select **GitHub Actions** as the source.

Run **Actions → Update merged ESign repo → Run workflow**.

The final ESign URL is:

`https://QrioCT-Gamer.github.io/REPO/esign.json`
